import React from 'react';
import './Appr.css';
import Form from './Form';

function Appr() {
  return (
    <div className="App">
      <Form />
    </div>
  );
}

export default Appr;
