package in.edac.model;

public enum TaskStatus {
    TO_DO, IN_PROGRESS,IN_REVIEW,DONE
}
